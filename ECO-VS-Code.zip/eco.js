const demoData = {
  years: ['2020', '2021', '2022', '2023', '2024', '2025'],
  gdp: [1.9, 7.4, 5.7, 6.3, 6.5, 6.1],
  inflation: [11.1, 10.8, 12.3, 10.0, 9.8, 9.2]
};

const chartCanvas = document.getElementById('economyChart');
let economyChart;

function createChart(range = 'all') {
  if (!chartCanvas || typeof Chart === 'undefined') return;
  const startIndex = range === 'recent' ? 3 : 0;
  const labels = demoData.years.slice(startIndex);
  if (economyChart) economyChart.destroy();

  economyChart = new Chart(chartCanvas, {
    type: 'line',
    data: {
      labels,
      datasets: [
        {
          label: 'GDP growth',
          data: demoData.gdp.slice(startIndex),
          borderColor: '#29966b',
          backgroundColor: 'rgba(41,150,107,.08)',
          borderWidth: 2.5,
          pointRadius: 3,
          pointHoverRadius: 5,
          pointBackgroundColor: '#29966b',
          tension: 0.35,
          fill: true
        },
        {
          label: 'Inflation',
          data: demoData.inflation.slice(startIndex),
          borderColor: '#e8a18d',
          backgroundColor: 'rgba(232,161,141,.05)',
          borderWidth: 2.5,
          pointRadius: 3,
          pointHoverRadius: 5,
          pointBackgroundColor: '#e8a18d',
          tension: 0.35,
          fill: false
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#17231f',
          padding: 11,
          displayColors: true,
          callbacks: { label: context => ` ${context.dataset.label}: ${context.parsed.y}%` }
        }
      },
      scales: {
        x: {
          grid: { display: false },
          border: { display: false },
          ticks: { color: '#8a958e', font: { family: 'DM Sans', size: 10 } }
        },
        y: {
          beginAtZero: true,
          border: { display: false, dash: [3, 4] },
          grid: { color: '#edf0ed', drawTicks: false },
          ticks: {
            color: '#8a958e',
            padding: 9,
            font: { family: 'DM Sans', size: 10 },
            callback: value => `${value}%`
          }
        }
      }
    }
  });
}

const amountInput = document.getElementById('amount');
const rateInput = document.getElementById('rate');
const yearsInput = document.getElementById('years');
const futurePrice = document.getElementById('futurePrice');
const increaseText = document.getElementById('increaseText');

function updateCalculator() {
  const amount = Number(amountInput.value);
  const rate = Number(rateInput.value);
  const years = Number(yearsInput.value);

  if (!Number.isFinite(amount) || !Number.isFinite(rate) || amount < 0 || rate <= -100 || rate > 1000) {
    futurePrice.textContent = 'Check your inputs';
    increaseText.textContent = 'Enter a non-negative price and a valid inflation rate.';
    return;
  }

  const future = amount * Math.pow(1 + rate / 100, years);
  const difference = future - amount;
  const format = value => new Intl.NumberFormat('en-US', {
    maximumFractionDigits: 0
  }).format(value);

  futurePrice.textContent = `${format(future)} UZS`;
  const sign = difference >= 0 ? 'Increase' : 'Decrease';
  increaseText.textContent = `${sign} of ${format(Math.abs(difference))} UZS over ${years} ${years === 1 ? 'year' : 'years'}`;
}

document.getElementById('chartRange')?.addEventListener('change', event => createChart(event.target.value));
[amountInput, rateInput, yearsInput].forEach(input => input?.addEventListener('input', updateCalculator));

const menuButton = document.getElementById('menuButton');
const sidebar = document.getElementById('sidebar');
menuButton?.addEventListener('click', () => sidebar.classList.toggle('open'));
document.querySelectorAll('.nav-link').forEach(link => {
  link.addEventListener('click', () => {
    document.querySelectorAll('.nav-link').forEach(item => item.classList.remove('active'));
    link.classList.add('active');
    sidebar.classList.remove('open');
  });
});

createChart();
updateCalculator();
