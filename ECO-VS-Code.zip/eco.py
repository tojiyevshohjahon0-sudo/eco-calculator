"""ECO — small economics data helper.

This script is optional. It demonstrates how to calculate the future price
after inflation using Python. Run with: python eco.py
"""

def future_price(current_price: float, annual_inflation_percent: float, years: int) -> float:
    """Calculate an estimated future price with annual compounding."""
    if current_price < 0:
        raise ValueError("Current price cannot be negative.")
    if annual_inflation_percent <= -100:
        raise ValueError("Inflation rate must be greater than -100%.")
    if years < 0:
        raise ValueError("Years cannot be negative.")

    return current_price * (1 + annual_inflation_percent / 100) ** years


if __name__ == "__main__":
    price = 1_000_000
    inflation = 9
    years = 3
    result = future_price(price, inflation, years)

    print("ECO — Inflation Calculator")
    print(f"Current price: {price:,.0f} UZS")
    print(f"Annual inflation: {inflation}%")
    print(f"Years: {years}")
    print(f"Estimated future price: {result:,.0f} UZS")
    print("Note: This is a mathematical estimate, not an official forecast.")
